package nl.davidversluis.picaria;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

public class Boardscreen extends AppCompatActivity {

    DrawView drawView;
    Board board;
    boolean player1AI;
    boolean player2AI;

    public void init()
    {
        //drawView = new DrawView(this,board,3);
        this.board = new Board(3,3,player1AI,player2AI);
        setContentView(R.layout.activity_boardscreen);
        ViewGroup layout = (ViewGroup) findViewById(R.id.boardscreen);
        drawView = new DrawView(this,board);
        drawView.setBackgroundColor(Color.LTGRAY);
        drawView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        layout.addView(drawView);
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.player1AI = getIntent().getExtras().getBoolean("P1AI");
        this.player2AI = getIntent().getExtras().getBoolean("P2AI");
        init();



        //ConstraintLayout overview = findViewById(R.id.singlenormal);
        //setContentView(overview);

        //drawView.setText("Added tv");

        //layout.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        //R.layout.activity_singlenormal.addView(drawView);
        //setContentView(drawView);
        //
        //setContentView(findViewById(R.id.button6));


    }
    public void resetboard(View view) {
        init();
        this.drawView.invalidate();
    }
    public void skipturn(View view)
    {
        if(drawView.winstate == 'f') {
            //this.board.makeAImove();
            this.board.changeplayer();
            this.drawView.winstate = this.board.checkwin(this.board.multi);
            this.drawView.invalidate();
        }
    }
}